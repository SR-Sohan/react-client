import React from 'react'

const DashHome = () => {
  return (
    <div>
      Dashboard Home
    </div>
  )
}

export default DashHome
