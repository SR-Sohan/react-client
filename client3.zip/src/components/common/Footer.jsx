const Footer = () => {
    return(
       <footer className="bg-primary py-5">
        <p className="text-center text-white">This is Footer</p>
       </footer>
    );
}

export default Footer;