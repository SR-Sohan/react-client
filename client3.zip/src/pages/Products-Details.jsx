const ProductsDetails = () => {
    return(
        <>
        
        </>
    );
}

export default ProductsDetails;