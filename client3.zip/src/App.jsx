import AppRouting from "./AppRouting"
// function App() {
//   return <AppRouting/>;
// }
const App = () => <AppRouting/>;

export default App
