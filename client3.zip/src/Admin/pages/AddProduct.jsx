import React from 'react'

const AddProduct = () => {
  return (
    <div>
      <h1>Add Product</h1>
    </div>
  )
}

export default AddProduct
